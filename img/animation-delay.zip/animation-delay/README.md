# Animation delay

A Pen created on CodePen.io. Original URL: [https://codepen.io/yuanchuan/pen/yLjaERw](https://codepen.io/yuanchuan/pen/yLjaERw).

